from funcs.testfunc1 import *
