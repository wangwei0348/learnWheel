def testfunc1():
    print("This is testfunc1.")
    return

if __name__ == '__main__':
    testfunc1()

