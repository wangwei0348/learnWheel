from distutils.core import setup

setup(
    name='funcs',
    version='0.1.0',
    description='A data analysis project',
    long_description='',
    author='Data Analyst',
    author_email='data_analyst@example.com',
    url='',
    py_modules=[
       'funcs.testfunc1'
    ]
)

